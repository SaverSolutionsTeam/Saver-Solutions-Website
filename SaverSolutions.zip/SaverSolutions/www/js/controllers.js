angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('loginCtrl', function($scope, $state) {
    
  $(document).ready(function() {
     $('input[type="submit"]').prop('disabled', true);
     $('input[type="text"]').keyup(function() {
        if($(this).val() != '') {
           $('input[type="submit"]').prop('disabled', false);
        }
     });
 });
    
      	$scope.login = function(email,password){
	      	console.log(email);
            
             $state.go('app.profile');
            
            if(email !="" && password !=""){
				$scope.message = "Fill in the entire entries"; 
            	}
            
//             if (email.indexOf("@")==-1){
//        $scope.message = "Please input a valid email address!";
//                }
            
                      }, function(error) {
                    //rejected, could log the error with: console.log('error', error);
                    	console.log('error', error);
                  }
        
        $scope.register = function(){
        
            $state.go('register');
        
        }
         
//	      	$scope.toIntro = function(){
//    window.localStorage['didTutorial'] = "false";
//    $state.go('intro');

//  }
})

.controller('registerCtrl', function($scope, $state) {
     $(document).ready(function() {
     $('input[type="submit"]').prop('disabled', true);
     $('input[type="text"]').keyup(function() {
        if($(this).val() != '') {
           $('input[type="submit"]').prop('disabled', false);
        }
     });
 });
    
      	$scope.register = function(fname,lname,email,cellnum,password, confpass){
	      	console.log(fname);
            
//            if(fname !="" || lname !="" || email !="" || cellnum !="" || password !="" || confpass !="") {
//				$scope.message = "Fill in the entire entries"; 
//            }
                
                if(fname.length < 3){
                     $scope.message = "First Name too short";
                } 
                if(lname.length < 3){
                $scope.message = "Last Name too short";
            }
            
             if (email.indexOf("@")==-1){
        $scope.message = "Please input a valid Email address!";
                }
            
             var phoneno = /^\d{10}$/;  
                if(!cellnum.match(phoneno))  
                {  
                    $scope.message = "Not a valid Cellphone Number";  
                }
            
            if(!password.match(confpass)){
                $scope.message = "Passwords do not match";
            }else{
                 $state.go(main);
            }
            
            
                      }, function(error) {
                    //rejected, could log the error with: console.log('error', error);
                    	console.log('error', error);
                  }
        
})

.controller('profileCtrl', function($scope, $ionicPopover) {

    function DropDown(el) {
        this.dd = el;
        this.initEvents();
    }
    DropDown.prototype = {
        initEvents : function() {
            var obj = this;

            obj.dd.on('click', function(event){
                $(this).toggleClass('active');
                    event.stopPropagation();
            });	
        }                                                                                                          }

    $(function() {

        var dd = new DropDown( $('#dd3') );

            $(document).click(function() {
                // all dropdowns
                $('.wrapper-dropdown-3').removeClass('active');
            });

    });
    
    $ionicPopover.fromTemplateUrl('templates/profile.html', {
    scope: $scope,
  }).then(function(popover) {
    $scope.popover = popover;
  });

  $scope.demo = 'android';
  $scope.setPlatform = function(p) {
    document.body.classList.remove('platform-ios');
    document.body.classList.remove('platform-android');
    document.body.classList.add('platform-' + p);
    $scope.demo = p;
  }

});
